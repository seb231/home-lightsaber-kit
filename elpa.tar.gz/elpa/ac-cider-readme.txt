Provides a number of auto-complete sources for Clojure projects using CIDER
and compliment. This is a replacement for now deprecated ac-nrepl project by
Steve Purcell.

Installation:

Available as a package in melpa.org.
M-x package-install ac-cider
